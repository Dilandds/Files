
#ifndef RENTED_COMMON_H
#define RENTED_COMMON_H


extern int check ;
extern int check_pending ;
extern int check_rent ;



#endif //RENTED_COMMON_H
